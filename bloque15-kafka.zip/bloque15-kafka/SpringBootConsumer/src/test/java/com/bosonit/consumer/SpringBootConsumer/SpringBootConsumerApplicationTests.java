package com.bosonit.consumer.SpringBootConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}

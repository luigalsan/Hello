package com.bosonit.provider.SpringBootProvider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
